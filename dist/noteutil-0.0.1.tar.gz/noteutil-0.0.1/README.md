# note_utility
Python program to turn notes into usable data structures
